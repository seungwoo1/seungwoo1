package com.kosmo.kkomoadopt.enums;

public enum QnAState {
    ANSWAIT, // 답변 대기
    ANSCOMPLETE // 답변 완료
}
