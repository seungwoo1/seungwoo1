package com.kosmo.kkomoadopt.enums;

public enum PostCategory {
    ANNOUNCEMENT, // 공지사항
    FINDCHILD, // 아이를찾습니다
    ADOPTREVIEW, // 입양후기
    BUYANDSELL, // 사고팝니다
    REPORT // 신고합니다
}
