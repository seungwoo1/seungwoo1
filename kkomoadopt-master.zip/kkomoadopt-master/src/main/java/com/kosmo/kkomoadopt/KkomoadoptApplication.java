package com.kosmo.kkomoadopt;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class


KkomoadoptApplication {

	public static void main(String[] args) {
		SpringApplication.run(KkomoadoptApplication.class, args);
	}
}

