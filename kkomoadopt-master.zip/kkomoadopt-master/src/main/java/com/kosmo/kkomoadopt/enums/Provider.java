package com.kosmo.kkomoadopt.enums;

public enum Provider {
    NAVER, // 네이버
    KAKAO, // 카카오
    NORMAL // 일반 회원가입
}
