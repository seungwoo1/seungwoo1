package com.kosmo.kkomoadopt.enums;

public enum NoticeCategory {
    ALL, // 전체
    DOG, // 강아지
    CAT, // 고양이
    OTHERS // 기타동물
}
