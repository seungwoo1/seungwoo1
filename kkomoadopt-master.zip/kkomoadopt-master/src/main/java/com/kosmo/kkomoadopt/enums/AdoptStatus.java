package com.kosmo.kkomoadopt.enums;

public enum AdoptStatus {
    ALL, // 전체
    ADOPTABLE, // 입양가능
    RESERVATION, // 예약중
    NOTADOPT // 입양불가
}
