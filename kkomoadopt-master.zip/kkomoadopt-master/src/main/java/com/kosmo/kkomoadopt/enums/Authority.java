package com.kosmo.kkomoadopt.enums;

public enum Authority {
    USER, // 유저
    ADMIN // 어드민
}
