package com.kosmo.kkomoadopt.enums;

public enum VisitPurpose {
    ADOPT, // 입양
    VISIT, // 단순 방문
    DONATE, // 후원
    SERVICE, // 봉사
    OTHER // 기타
}
