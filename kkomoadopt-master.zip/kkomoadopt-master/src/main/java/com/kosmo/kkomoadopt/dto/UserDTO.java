package com.kosmo.kkomoadopt.dto;

public record UserDTO(
        String username,
        String password
) {
}
