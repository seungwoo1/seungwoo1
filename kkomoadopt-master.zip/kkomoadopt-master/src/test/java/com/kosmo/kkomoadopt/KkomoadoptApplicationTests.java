package com.kosmo.kkomoadopt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class KkomoadoptApplicationTests {

	@Test
	void contextLoads() {
	}

}
