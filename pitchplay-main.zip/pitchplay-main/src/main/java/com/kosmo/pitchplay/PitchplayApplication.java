package com.kosmo.pitchplay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class PitchplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(PitchplayApplication.class, args);
	}

}
