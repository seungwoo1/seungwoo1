package com.kosmo.pitchplay.enums;

public enum TeamRole {
    LEADER,
    MANAGER,
    MEMBER
}
