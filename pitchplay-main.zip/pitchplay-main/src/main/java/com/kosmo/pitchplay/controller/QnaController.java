package com.kosmo.pitchplay.controller;

public class QnaController {
}
