package com.kosmo.pitchplay.enums;

public enum QnaType {
    SUGGESTION, // 건의제보
    MANNER_REPORT // 매너제재
}
