package com.kosmo.pitchplay.enums;

// 유저 캐시 내역
public enum TransactionType {
    CHARGE, // 충전
    USE,   // 사용
    REFUND // 환불
}
