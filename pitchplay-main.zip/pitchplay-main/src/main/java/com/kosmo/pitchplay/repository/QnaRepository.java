package com.kosmo.pitchplay.repository;

public interface QnaRepository {
}
