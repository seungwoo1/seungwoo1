package com.kosmo.pitchplay.enums;

public enum NoticeType {
    ANNOUNCEMENT, //공지사항
    FAQ //자주하는 질문
}
