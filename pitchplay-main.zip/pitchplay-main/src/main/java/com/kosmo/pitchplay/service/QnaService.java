package com.kosmo.pitchplay.service;

public class QnaService {
}
