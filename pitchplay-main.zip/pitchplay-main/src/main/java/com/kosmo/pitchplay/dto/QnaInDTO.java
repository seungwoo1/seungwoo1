package com.kosmo.pitchplay.dto;

public class QnaInDTO {
}
