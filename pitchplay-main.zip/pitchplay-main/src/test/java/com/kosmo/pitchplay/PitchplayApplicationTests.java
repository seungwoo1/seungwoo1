package com.kosmo.pitchplay;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PitchplayApplicationTests {

	@Test
	void contextLoads() {
	}

}
